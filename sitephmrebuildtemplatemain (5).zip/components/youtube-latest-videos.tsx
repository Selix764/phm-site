"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Play, Calendar } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

interface YouTubeVideo {
  id: string
  title: string
  thumbnail: string
  publishedAt: string
}

export function YouTubeLatestVideos() {
  const [videos, setVideos] = useState<YouTubeVideo[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // These are actual published videos from the PERFECTHOMEMEDIA channel
    const publishedVideos = [
      {
        id: "Yd-Uc8_QgSI",
        title: "Voluntari sunt și cei care fac bine fără să știe nimeni.",
        thumbnail:
          "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/mqdefault_16s-7L8m6AuBe8lcmLpRGCFTogd9VQ9ZAu.webp",
        publishedAt: "2023-05-15T10:00:00Z",
      },
      {
        id: "9XyQ94jQPxo",
        title: "Alimente sănătoase primăvara",
        thumbnail:
          "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/mqdefault_6s-DYQ9ZN7MYATxzf7lkLkkd8D8yLJvZG.webp",
        publishedAt: "2023-06-20T14:30:00Z",
      },
      {
        id: "bKT3L1T8JKo",
        title: "La casă ori la bloc?",
        thumbnail:
          "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/mqdefault_26s-vCLAdmW62s1laEuwpYOpICd69LrKvx.webp",
        publishedAt: "2023-07-10T09:15:00Z",
      },
    ]

    setVideos(publishedVideos)
    setLoading(false)
  }, [])

  if (loading) {
    return (
      <div className="w-full py-8">
        <div className="animate-pulse flex flex-col space-y-4">
          <div className="h-4 bg-[#1A1A1A] rounded w-1/4"></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-64 bg-[#1A1A1A] rounded-xl"></div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="w-full py-8">
      <div className="flex items-center gap-3 mb-6">
        <Play className="text-[#FF0000] w-6 h-6" />
        <h3 className="text-2xl font-bold text-white">Ultimele videoclipuri</h3>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {videos.map((video, index) => (
          <motion.div
            key={video.id + index}
            className="bg-[#1A1A1A] rounded-xl overflow-hidden group cursor-pointer"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: index * 0.1 }}
            whileHover={{ y: -10, transition: { duration: 0.2 } }}
          >
            <Link
              href={`https://www.youtube.com/watch?v=${video.id}`}
              target="_blank"
              rel="noopener noreferrer"
              className="block"
            >
              <div className="relative aspect-video">
                <Image src={video.thumbnail || "/placeholder.svg"} alt={video.title} fill className="object-cover" />
                <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="w-16 h-16 rounded-full bg-[#FF0000]/80 flex items-center justify-center">
                    <Play className="w-8 h-8 text-white" />
                  </div>
                </div>
              </div>
              <div className="p-4">
                <h4 className="text-white font-medium line-clamp-2 mb-2">{video.title}</h4>
                <div className="flex items-center text-white/60 text-sm">
                  <Calendar className="w-4 h-4 mr-1" />
                  {new Date(video.publishedAt).toLocaleDateString("ro-RO")}
                </div>
              </div>
            </Link>
          </motion.div>
        ))}
      </div>

      <div className="mt-6 text-center">
        <p className="text-white/70 mb-4">
          Aici sunt afișate doar videoclipurile publicate, nu și cele programate pentru viitor.
        </p>
        <Link
          href="https://www.youtube.com/@PERFECTHOMEMEDIA/videos"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center text-[#FF0000] hover:underline font-medium"
        >
          Vezi toate videoclipurile
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="ml-1"
          >
            <path d="M5 12h14" />
            <path d="m12 5 7 7-7 7" />
          </svg>
        </Link>
      </div>
    </div>
  )
}
